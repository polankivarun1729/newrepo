//
//  ViewController.swift
//  frame
//
//  Created by Varun Kumar on 20/06/18.
//  Copyright © 2018 Varun Kumar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let lbl = UILabel(frame: CGRect(x: self.view.frame.midX, y: 50, width: self.view.frame.width, height: 40))
        // Do any additional setup after loading the view, typically from a nib.
        let vv = UIView(frame: CGRect(x: 0, y: 100, width: self.view.frame.width, height: 40))
        let vie = UIView(frame: CGRect(x: 0 , y: 100, width: self.view.frame.width, height: 50))
        let vi = UIView(frame: CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height))
        vi.backgroundColor = UIColor.gray
        vie.backgroundColor = UIColor.red
        vv.backgroundColor = UIColor.green
        lbl.text = "Varunkumar"
        lbl.textColor = UIColor.white
        
        self.view.addSubview(vi)
        vi.addSubview(vie)
        vie.addSubview(vv)
        vie.addSubview(lbl)
       
        let btn: UIButton = UIButton(frame: CGRect(x: 0, y: 400, width: self.view.frame.width, height: 50))
        btn.backgroundColor = UIColor.clear
        btn.setTitle("Click Me", for: .normal)
        btn.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        btn.tag = 1
        self.view.addSubview(btn)
        
        
    }
    @objc func buttonAction(sender:UIButton!){
        for i in 0...10{
            if i % 2 == 1 {
                print(i)
            }
            
        }
    }

   


}

